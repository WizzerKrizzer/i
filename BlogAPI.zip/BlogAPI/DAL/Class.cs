﻿namespace BlogAPI.DAL
{
    public class Class
    {
    }
}
